# sheridanesports
This is the Sheridan eSports Github for the sheridanesports.ca site
