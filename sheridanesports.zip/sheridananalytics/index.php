<html>
<form method="post" action="main.php/" id="uform">
    <p>
        <label for="uname">Username: </label>
        <input type="text" name="uname" id="uname"/>
    </p>      	
    <p>
	   <input class="btn btn-default" type="submit" value="Submit &raquo;"/>
    </p>
</form>
</html>
